A Pen created at CodePen.io. You can find this one at http://codepen.io/drawcd/pen/NgRZjP.

 Get your drum on with with buckets, cans, pots and more. Click, tap or use your keyboard to play.  Drawn in Illustrator, animated with GSAP/Greensock, sound designed in Ableton Live.

Pen inspired by mind-blowing street percussionists in cities around the world,  @iamjoshellis' rad [SVG Animated Drum Kit](http://codepen.io/iamjoshellis/pen/KVdQqm) and all sorts of @sdras pens like this one called [Keypress](http://codepen.io/sdras/pen/zvXbGJ)